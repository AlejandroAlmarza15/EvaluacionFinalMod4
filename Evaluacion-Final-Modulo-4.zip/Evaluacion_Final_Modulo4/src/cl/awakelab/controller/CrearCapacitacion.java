package cl.awakelab.controller;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cl.awakelab.model.Capacitacion;
import cl.awakelab.model.dao.CapacitacionDAOImpl;



/**
 * Servlet implementation class CrearCapacitacion
 */
@WebServlet("/CrearCapacitacion")
public class CrearCapacitacion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CrearCapacitacion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//request.getRequestDispatcher("CrearCapacitacion.jsp").forward(request, response);
		getServletContext().getRequestDispatcher("/CrearCapacitacion.jsp").forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		Capacitacion c = new Capacitacion(Integer.parseInt(request.getParameter("idcapacitacion")), request.getParameter("capfecha"), 
				request.getParameter("caphora"), request.getParameter("caplugar"), Integer.parseInt(request.getParameter("capduracion")), 
				request.getParameter("cliente_rutcliente"));
		
		CapacitacionDAOImpl capDAO = new CapacitacionDAOImpl();
		capDAO.createCapacitacion(c);
		
		getServletContext().getRequestDispatcher("/Inicio.jsp").forward(request, response);
		
		
		
	}

}