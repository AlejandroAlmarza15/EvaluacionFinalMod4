package cl.awakelab.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cl.awakelab.model.dao.AdministrativoDAOImpl;
import cl.awakelab.model.dao.ClienteDAOImpl;
import cl.awakelab.model.dao.ProfesionalDAOImpl;
import cl.awakelab.model.Administrativo;
import cl.awakelab.model.Cliente;
import cl.awakelab.model.Profesional;

/**
 * Servlet implementation class EditarUsuario
 */
@WebServlet("/EditarUsuario")
public class EditarUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditarUsuario() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String run_usuario = request.getParameter("id");
		int tipo_usuario = Integer.parseInt(request.getParameter("tipo"));
		
		if(tipo_usuario == 1) {
			
			ClienteDAOImpl cimpl = new ClienteDAOImpl();
			Cliente clienteaux = cimpl.obtenerUsuarioPorId(run_usuario);
			
			request.setAttribute("us", clienteaux);
			request.getRequestDispatcher("/formeditarcliente.jsp").forward(request, response);
			
		}else if(tipo_usuario == 2) {
			
			AdministrativoDAOImpl aimpl = new AdministrativoDAOImpl();
			Administrativo admaux = aimpl.obtenerUsuarioPorId(run_usuario);
			
			request.setAttribute("us", admaux);
			request.getRequestDispatcher("/formeditaradministrativo.jsp").forward(request, response);
			
		}else if(tipo_usuario == 3) {
			
			ProfesionalDAOImpl pimpl = new ProfesionalDAOImpl();
			Profesional paux = pimpl.obtenerUsuarioPorId(run_usuario);
			
			request.setAttribute("us", paux);
			request.getRequestDispatcher("/formeditarprofesional.jsp").forward(request, response);
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
