package cl.awakelab.model.dao;

import java.util.List;

import cl.awakelab.model.Usuario;
import cl.awakelab.model.Administrativo;
import cl.awakelab.model.Cliente;
import cl.awakelab.model.Profesional;

public interface IUsuarioDAO {

	public List<Usuario> obtenerUsuario();

	public boolean crearUsuario(Usuario usuario, Cliente cliente);

	public boolean crearUsuario1(Usuario usuario, Administrativo administrativo);

	public boolean crearUsuario2(Usuario usuario, Profesional profesional);

	public boolean editarUsuario(Usuario usuario, Cliente cliente);

}
