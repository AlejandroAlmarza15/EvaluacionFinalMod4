package cl.awakelab.model;

public class Profesional {

	private String runpro;
	private String nombres;
	private String apellidos;
	private String telefono;
	private String tituloprofesional;
	private String proyecto;
	private String usuario_runusuario;

	public Profesional() {
		super();
	}

	public Profesional(String runpro, String nombres, String apellidos, String telefono, String tituloprofesional,
			String proyecto, String usuario_run) {
		super();
		this.runpro = runpro;
		this.nombres = nombres;
		this.apellidos = apellidos;
		this.telefono = telefono;
		this.tituloprofesional = tituloprofesional;
		this.proyecto = proyecto;
		this.usuario_runusuario = usuario_run;
	}

	public String getRunpro() {
		return runpro;
	}

	public void setRunpro(String runpro) {
		this.runpro = runpro;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getTituloprofesional() {
		return tituloprofesional;
	}

	public void setTituloprofesional(String tituloprofesional) {
		this.tituloprofesional = tituloprofesional;
	}

	public String getProyecto() {
		return proyecto;
	}

	public void setProyecto(String proyecto) {
		this.proyecto = proyecto;
	}

	public String getUsuario_runusuario() {
		return usuario_runusuario;
	}

	public void setUsuario_runusuario(String usuario_runusuario) {
		this.usuario_runusuario = usuario_runusuario;
	}

	@Override
	public String toString() {
		return "Profesional [runpro=" + runpro + ", nombres=" + nombres + ", apellidos=" + apellidos + ", telefono="
				+ telefono + ", tituloprofesional=" + tituloprofesional + ", proyecto=" + proyecto + ", usuario_runusuario="
				+ usuario_runusuario + "]";
	}

}
