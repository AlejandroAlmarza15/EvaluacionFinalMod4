package cl.awakelab.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cl.awakelab.model.dao.UsuarioDAOImpl;
import cl.awakelab.model.Administrativo;
import cl.awakelab.model.Cliente;
import cl.awakelab.model.Profesional;
import cl.awakelab.model.Usuario;

/**
 * Servlet implementation class InsertarUsuario
 */
@WebServlet("/InsertarUsuario")
public class InsertarUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertarUsuario() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		Usuario usu = new Usuario();
		Cliente cli = new Cliente();
		Administrativo adm = new Administrativo();
		Profesional pro = new Profesional();
		
		String run = request.getParameter("txtrun");
		String nombre = request.getParameter("txtnombre");
		String apellido = request.getParameter("txtapellido");
		String fecha = request.getParameter("txtfecha");
		int tipo = Integer.parseInt(request.getParameter("tipousuario"));
		
		usu.setRunusuario(run);
		usu.setNombre(nombre);
		usu.setApellido(apellido);
		usu.setFechanacimiento(fecha);
		usu.setTipo(tipo);
		
		if(tipo == 1) {
			String rutcliente = request.getParameter("rutcliente");
			String clinombres = request.getParameter("clinombres");
			String cliapellidos = request.getParameter("cliapellidos");
			String clitelefono = request.getParameter("clitelefono");
			String cliafp = request.getParameter("cliafp");
			int clisistemasalud = Integer.parseInt(request.getParameter("salud"));
			String clidireccion = request.getParameter("clidireccion");
			String clicomuna = request.getParameter("clicomuna");
			int cliedad = Integer.parseInt(request.getParameter("cliedad"));
			//String usuario_runusuario = request.getParameter("runusuario");
			
			cli.setRutcliente(rutcliente);
			cli.setClinombres(clinombres);
			cli.setCliapellidos(cliapellidos);
			cli.setClitelefono(clitelefono);
			cli.setCliafp(cliafp);
			cli.setClisistemasalud(clisistemasalud);
			cli.setClidireccion(clidireccion);
			cli.setClicomuna(clicomuna);
			cli.setCliedad(cliedad);
			cli.setUsuario_runusuario(run);
			
			UsuarioDAOImpl usuimpl = new UsuarioDAOImpl();
			
			boolean res = usuimpl.crearUsuario(usu, cli);
			String msg = "";
			
			if (res) {
				msg = "El usuario se agreg� exitosamente";
			}
			else {
				msg = "El usuario no se pudo agregar porque ocurri� un error";
			}

			request.setAttribute("mensaje", msg);
			request.getRequestDispatcher("/msgusuario.jsp").forward(request, response);
			
		}else if(tipo == 2) {
			String runadm = request.getParameter("runadm");
			String nombres = request.getParameter("nombres");
			String apellidos = request.getParameter("apellidos");
			String email = request.getParameter("email");
			String area = request.getParameter("area");
			//String usuario_runusuario = request.getParameter("usuario_runusuario");
			
			adm.setRunadm(runadm);
			adm.setNombres(nombres);
			adm.setApellidos(apellidos);
			adm.setEmail(email);
			adm.setArea(area);
			adm.setUsuario_runusuario(run);
			
			UsuarioDAOImpl usuimpl = new UsuarioDAOImpl();
			
			boolean res = usuimpl.crearUsuario1(usu, adm);
			String msg = "";
			
			if (res) {
				msg = "El usuario se agreg� exitosamente";
			}
			else {
				msg = "El usuario no se pudo agregar porque ocurri� un error";
			}

			request.setAttribute("mensaje", msg);
			request.getRequestDispatcher("/msgusuario.jsp").forward(request, response);
		}else if(tipo == 3) {
			String runpro = request.getParameter("runpro");
			String nombres = request.getParameter("nombres");
			String apellidos = request.getParameter("apellidos");
			String telefono = request.getParameter("telefono");
			String tituloprofesional = request.getParameter("tituloprofesional");
			String proyecto = request.getParameter("proyecto");
			//int usuario_run = Integer.parseInt(request.getParameter("usuario_run"));
			
			pro.setRunpro(runpro);
			pro.setNombres(nombres);
			pro.setApellidos(apellidos);
			pro.setTelefono(telefono);
			pro.setTituloprofesional(tituloprofesional);
			pro.setProyecto(proyecto);
			pro.setUsuario_runusuario(run);
			
			UsuarioDAOImpl usuimpl = new UsuarioDAOImpl();
			
			boolean res = usuimpl.crearUsuario2(usu, pro);
			String msg = "";
			
			if (res) {
				msg = "El usuario se agreg� exitosamente";
			}
			else {
				msg = "El usuario no se pudo agregar porque ocurri� un error";
			}

			request.setAttribute("mensaje", msg);
			request.getRequestDispatcher("/msgusuario.jsp").forward(request, response);
		}	
	}

}
