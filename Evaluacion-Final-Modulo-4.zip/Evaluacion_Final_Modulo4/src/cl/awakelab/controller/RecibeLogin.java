package cl.awakelab.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import cl.awakelab.model.Logear;

/**
 * Servlet implementation class RecibeLogin
 */
@WebServlet("/RecibeLogin")
public class RecibeLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RecibeLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at:").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String usuario = request.getParameter("txtusuario");
		String clave = request.getParameter("txtclave");
		
		if (usuario.equals("admin") && clave.equals("1234")) {
			Logear user = new Logear();
			user.setNombreusuario(usuario);
			user.setClave(clave);
			
			HttpSession misesion = request.getSession();
			misesion.setAttribute("sesionusuario", user);
			response.sendRedirect(request.getContextPath() + "/Contacto");
		}
		else {
			response.sendRedirect(request.getContextPath() + "/Login");
		}
		
	}

}

