package cl.awakelab.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Singleton {

	private static Connection con = null;

	Singleton() {
		try {

			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String usr = "EvaluacionM4";
			String psw = "1234";

			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(url, usr, psw);

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection() {
		if (con == null) {
			new Singleton();
		}

		return con;
	}

}
