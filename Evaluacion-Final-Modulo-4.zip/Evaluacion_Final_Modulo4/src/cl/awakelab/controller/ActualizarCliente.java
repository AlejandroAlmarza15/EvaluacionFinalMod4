package cl.awakelab.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cl.awakelab.model.dao.ClienteDAOImpl;
import cl.awakelab.model.Cliente;

/**
 * Servlet implementation class ActualizarCliente
 */
@WebServlet("/ActualizarCliente")
public class ActualizarCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActualizarCliente() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String rutcliente = request.getParameter("rutcliente");
		String clinombre = request.getParameter("clinombres");
		String cliapellido = request.getParameter("cliapellidos");
		String clitelefono = request.getParameter("clitelefono");
		String cliafp = request.getParameter("cliafp");
		int clisistemasalud = Integer.parseInt(request.getParameter("salud"));
		String clidireccion = request.getParameter("clidireccion");
		String clicomuna = request.getParameter("clicomuna");
		int  cliedad = Integer.parseInt(request.getParameter("cliedad"));
		String runusuario = "";
		
		Cliente cl = new Cliente(rutcliente, clinombre, cliapellido, clitelefono, cliafp, clisistemasalud,
				clidireccion, clicomuna, cliedad, runusuario);
		
		ClienteDAOImpl climpl = new ClienteDAOImpl();
		
		boolean res = climpl.editarCliente(cl);
		String msg = "";
		
		if (res) {
			msg = "El usuario cliente se edit� exitosamente";
		}
		else {
			msg = "El usuario cliente no se pudo editar porque ocurri� un error";
		}

		request.setAttribute("mensaje", msg);
		request.getRequestDispatcher("/msgcrearcliente.jsp").forward(request, response);
		
	}

}
