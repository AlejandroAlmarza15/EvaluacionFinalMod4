/**
 *funcionUusuario.js
 *Permite mostrar el formulario para crear un cliente dependiendo el tipo
 * 1.- cliente 2.- administrativo 3.- profesional  
*/

function cargartipo(){
	var tipo = document.getElementById("tipousuario");
	var a = tipo.value;
	
	if(a== 1){
		document.getElementById("contenido").innerHTML = 
				"<tr><td> RUN </td> <td> <input type='text' name='rutcliente' id='rutcliente'> </td></tr><br>"+
			"<tr><td> Nombres </td><td> <input type='text' name='clinombres' id='clinombres'></td></tr><br>"+
            "<tr><td> Apellidos </td><td> <input type='text' name='cliapellidos' id='cliapellidos'></td></tr><br>"+
			"<tr><td> Telefono </td><td> <input type='text' name='clitelefono' id='clitelefono'></td></tr><br>"+
            "<tr><td> AFP </td><td> <label for='Tipo_afp'>Seleccione una afp:</label><select name='cliafp' id='cliafp'>"+
				"<option value='modelo'>Modelo</option><option value='provida'>Provida</option>"+
				"<option value='habitat'>Habitat</option><option value='capital'>Capital</option>"+
				"<option value='plan vital'>Plan vital</option></select></td></tr><br>"+
			"<tr><td> Sistema salud </td><td> <label for='Tipo_Salud'>Seleccione un sistema de salud:</label>"+
			"<select name='salud' id='salud'><option value='1'>Fonasa</option><option value='2'>Isapre</option>"+
			"</select></td></tr><br>"+
			"<tr><td> Dirección </td><td> <input type='text' name='clidireccion' id='clidireccion'> </td></tr><br>"+
			"<tr><td> Comuna </td><td> <input type='text' name='clicomuna' id='clicomuna'></td></tr><br>"+
           "<tr><td> Edad </td><td> <input type='text' name='cliedad' id='cliedad'></td></tr>"

	}else if(a== 2){
		document.getElementById("contenido").innerHTML =
			"<tr><td> RUN administrativo </td> <td> <input type='text' name='runadm' id='runadm'> </td></tr><br>" +
			"<tr><td> Nombres </td><td> <input type='text' name='nombres' id='nombres'></td></tr><br>" +
			"<tr><td> Apellidos </td><td> <input type='text' name='apellidos' id='apellidos'></td></tr><br>" +
			"<tr><td> Correo Electrónico </td><td> <input type='text' name='email' id='email'></td></tr><br>" +
			"<tr><td> Area </td><td> <input type='text' name='area' id='area'></td></tr><br>"
	}else if(a== 3){
		document.getElementById("contenido").innerHTML = 
		    "<tr><td> RUN profesional </td> <td> <input type='text' name='runpro' id='runpro'> </td></tr><br>"+
			"<tr><td> Nombres </td><td> <input type='text' name='nombres' id='nombres'></td></tr><br>"+
            "<tr><td> Apellidos </td><td> <input type='text' name='apellidos' id='apellidos'></td></tr><br>"+
			"<tr><td> Teléfono </td><td> <input type='text' name='telefono' id='telefono'></td></tr><br>"+
			"<tr><td> Titulo del Profesional </td><td> <input type='text' name='tituloprofesional' id='tituloprofesional'></td></tr><br>"+	
			"<tr><td> Nombre del Proyecto </td><td> <input type='text' name='proyecto' id='proyecto'></td></tr><br>"
	}
}