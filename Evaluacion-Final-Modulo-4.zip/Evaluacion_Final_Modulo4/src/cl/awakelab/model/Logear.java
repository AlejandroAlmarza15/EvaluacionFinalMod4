package cl.awakelab.model;

public class Logear {
	
	private String nombreusuario;
	private String clave;
	
	public Logear() {
		super();
	}

	public Logear(String nombreusuario, String clave) {
		super();
		this.nombreusuario = nombreusuario;
		this.clave = clave;
	}

	public String getNombreusuario() {
		return nombreusuario;
	}

	public void setNombreusuario(String nombreusuario) {
		this.nombreusuario = nombreusuario;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	@Override
	public String toString() {
		return "Usuario [nombreusuario=" + nombreusuario + ", clave=" + clave + "]";
	}
	
}
