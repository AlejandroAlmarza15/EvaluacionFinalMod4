package cl.awakelab.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;


import cl.awakelab.model.Administrativo;


public class AdministrativoDAOImpl implements iAdministrativodao{

	@Override
	public Administrativo obtenerUsuarioPorId(String run_usuario) {
		// TODO Auto-generated method stub
		Connection con = null;
		Statement stm = null;
		ResultSet rs = null;
		Administrativo a = new Administrativo();
		String sql = "select * from administrativo where usuario_runusuario = '"+run_usuario+"'";
		
		try {
			con = Singleton.getConnection();
			stm = con.createStatement();
			rs = stm.executeQuery(sql);
			
			while (rs.next()) {
				a.setRunadm(rs.getString(1));
				a.setNombres(rs.getString(2));
				a.setApellidos(rs.getString(3));
				a.setEmail(rs.getString(4));
				a.setArea(rs.getString(5));
				a.setUsuario_runusuario(rs.getString(6));
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return a;
	}

	@Override
	public boolean editarAdministrativo(Administrativo administrativo) {
		// TODO Auto-generated method stub
		boolean resultado = false;
		Connection con = null;
		Statement stm = null;
		
		String sql = "UPDATE administrativo SET nombres = '" + administrativo.getNombres() + "', apellidos = '" 
		+ administrativo.getApellidos()+ "', email = '" + administrativo.getEmail()+ "', area = '" 
		+ administrativo.getArea()+ "' WHERE runadm = '" + administrativo.getRunadm() + "'";
		
		try {
			con = Singleton.getConnection();
			stm = con.createStatement();
			stm.execute(sql);
			resultado = true;
			stm.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return resultado;
	}

}
