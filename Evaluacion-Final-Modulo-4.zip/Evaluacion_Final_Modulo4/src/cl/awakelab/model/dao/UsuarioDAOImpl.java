package cl.awakelab.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cl.awakelab.model.Profesional;
import cl.awakelab.model.Usuario;


import cl.awakelab.model.dao.UsuarioDAOImpl;
import cl.awakelab.model.Administrativo;
import cl.awakelab.model.Cliente;

public class UsuarioDAOImpl implements IUsuarioDAO{

	@Override
	public List<Usuario> obtenerUsuario() {
		// TODO Auto-generated method stub
		Connection con = null;
		Statement stm = null;
		ResultSet rs = null;
		List<Usuario> listausuarios = new ArrayList<Usuario>();		
		String sql = "select * from usuario";
		
		try {
			con = Singleton.getConnection();
			stm = con.createStatement();
			rs = stm.executeQuery(sql);
			
			while (rs.next()) {
				Usuario u = new Usuario();
				u.setRunusuario(rs.getString(1));
				u.setNombre(rs.getString(2));
				u.setApellido(rs.getString(3));
				u.setFechanacimiento(rs.getString(4));
				u.setTipo(rs.getInt(5));
				listausuarios.add(u);
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return listausuarios;
	}

	
	@Override
	public boolean crearUsuario(Usuario usuario, Cliente cliente) {
		// TODO Auto-generated method stub
		boolean registrar = false;
		
		Statement stm = null;
		
		Connection con = null;
		
		String sql = "INSERT INTO USUARIO VALUES ('" 
				+ usuario.getRunusuario() + "','" 
				+ usuario.getNombre() + "','" 
				+ usuario.getApellido() + "','" 
				+ usuario.getFechanacimiento() + "','" 
				+ usuario.getTipo() + "')";
		
		try {
			con = Singleton.getConnection();
			stm = con.createStatement();
			stm.execute(sql);
			registrar = true;
			stm.close();
			//con.close();
		} catch (SQLException e) {
			System.out.println("Error: " + "Clase UsuarioDAOImpl, " + "m�todo crear Usuario");
			e.printStackTrace();
		}
		
		
			String sql1 = "INSERT INTO cliente VALUES ('" 
					+ cliente.getRutcliente() + "','" 
					+ cliente.getClinombres() + "','" 
					+ cliente.getCliapellidos() + "','" 
					+ cliente.getClitelefono() + "','" 
					+ cliente.getCliafp() + "','" 
					+ cliente.getClisistemasalud()+ "','"
					+ cliente.getClidireccion() + "','"
					+ cliente.getClicomuna() + "','" 
					+ cliente.getCliedad() + "','" 
					+ cliente.getUsuario_runusuario()+"')";
			
			try {
				con = Singleton.getConnection();
				stm = con.createStatement();
				stm.execute(sql1);
				registrar = true;
				stm.close();
				//con.close();
			} catch (SQLException e) {
				System.out.println("Error: " + "Clase UsuarioDAOImpl, " + "m�todo crear Usuario tipo ");
				e.printStackTrace();
			}
		
		
		return registrar;
	}

	@Override
	public boolean crearUsuario1(Usuario usuario, Administrativo administrativo) {
		// TODO Auto-generated method stub
		boolean registrar = false;
		
		Statement stm = null;
		
		Connection con = null;
		
		String sql = "INSERT INTO USUARIO VALUES ('" 
				+ usuario.getRunusuario() + "','" 
				+ usuario.getNombre() + "','" 
				+ usuario.getApellido() + "','" 
				+ usuario.getFechanacimiento() + "','" 
				+ usuario.getTipo() + "')";
		
		
		try {
			con = Singleton.getConnection();
			stm = con.createStatement();
			stm.execute(sql);
			registrar = true;
			stm.close();
			//con.close();
		} catch (SQLException e) {
			System.out.println("Error: " + "Clase UsuarioDAOImpl, " + "m�todo crear Usuario");
			e.printStackTrace();
		}
		
		String sql1 = "INSERT INTO administrativo VALUES ('" 
				+ administrativo.getRunadm() + "','" 
				+ administrativo.getNombres() + "','" 
				+ administrativo.getApellidos() + "','" 
				+ administrativo.getEmail() + "','" 
				+ administrativo.getArea()+ "','" 
				+ administrativo.getUsuario_runusuario()+"')";
		
		try {
			con = Singleton.getConnection();
			stm = con.createStatement();
			stm.execute(sql1);
			registrar = true;
			stm.close();
			//con.close();
		} catch (SQLException e) {
			System.out.println("Error: " + "Clase UsuarioDAOImpl, " + "m�todo crear Usuario tipo Administrativo");
			e.printStackTrace();
		}
	
	
		return registrar;
	}

	@Override
	public boolean crearUsuario2(Usuario usuario, Profesional profesional) {
		// TODO Auto-generated method stub
		boolean registrar = false;
		
		Statement stm = null;
		
		Connection con = null;
		
		String sql = "INSERT INTO USUARIO VALUES ('" 
				+ usuario.getRunusuario() + "','" 
				+ usuario.getNombre() + "','" 
				+ usuario.getApellido() + "','" 
				+ usuario.getFechanacimiento() + "','" 
				+ usuario.getTipo() + "')";
		
		
		try {
			con = Singleton.getConnection();
			stm = con.createStatement();
			stm.execute(sql);
			registrar = true;
			stm.close();
			
		} catch (SQLException e) {
			System.out.println("Error: " + "Clase UsuarioDAOImpl, " + "m�todo crear Usuario");
			e.printStackTrace();
		}
		
		
			String sql1 = "INSERT INTO profesional VALUES ('" 
					+ profesional.getRunpro() + "','" 
					+ profesional.getNombres() + "','" 
					+ profesional.getApellidos() + "','" 
					+ profesional.getTelefono() + "','" 
					+ profesional.getTituloprofesional() + "','" 
					+ profesional.getProyecto()+ "','"
					+ profesional.getUsuario_runusuario()+"')";
			
			try {
				con = Singleton.getConnection();
				stm = con.createStatement();
				stm.execute(sql1);
				registrar = true;
				stm.close();
				//con.close();
			} catch (SQLException e) {
				System.out.println("Error: " + "Clase UsuarioDAOImpl, " + "m�todo crear Usuario tipo Profesional");
				e.printStackTrace();
			}
		
		
		return registrar;
	}

	@Override
	public boolean editarUsuario(Usuario usuario, Cliente cliente) {
		// TODO Auto-generated method stub
		return false;
	}

	

}
