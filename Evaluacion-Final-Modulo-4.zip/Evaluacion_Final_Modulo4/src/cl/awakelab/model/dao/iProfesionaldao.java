package cl.awakelab.model.dao;

import cl.awakelab.model.Profesional;

public interface iProfesionaldao {

	public Profesional obtenerUsuarioPorId(String runusuario);
	
	public boolean editarProfesional(Profesional profesional);
}
