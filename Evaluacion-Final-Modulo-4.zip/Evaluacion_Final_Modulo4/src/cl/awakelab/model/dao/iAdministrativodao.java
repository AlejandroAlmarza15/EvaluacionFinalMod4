package cl.awakelab.model.dao;

import cl.awakelab.model.Administrativo;

public interface iAdministrativodao {
	
	public Administrativo obtenerUsuarioPorId(String runusuario);
	
	public boolean editarAdministrativo(Administrativo administrativo);
}
