package cl.awakelab.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import cl.awakelab.model.Profesional;

public class ProfesionalDAOImpl implements iProfesionaldao {

	@Override
	public Profesional obtenerUsuarioPorId(String run_runusuario) {
		// TODO Auto-generated method stub
		Connection con = null;
		Statement stm = null;
		ResultSet rs = null;
		Profesional p = new Profesional();
		String sql = "select * from profesional where usuario_runusuario = '" + run_runusuario + "'";

		try {
			con = Singleton.getConnection();
			stm = con.createStatement();
			rs = stm.executeQuery(sql);

			while (rs.next()) {
				p.setRunpro(rs.getString(1));
				p.setNombres(rs.getString(2));
				p.setApellidos(rs.getString(3));
				p.setTelefono(rs.getString(4));
				p.setTituloprofesional(rs.getString(5));
				p.setProyecto(rs.getString(6));
				p.setUsuario_runusuario(rs.getString(7));
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return p;
	}

	@Override
	public boolean editarProfesional(Profesional profesional) {
		// TODO Auto-generated method stub
		boolean resultado = false;
		Connection con = null;
		Statement stm = null;

		String sql = "UPDATE profesional SET nombres = '" + profesional.getNombres() + "', apellidos = '"
				+ profesional.getApellidos() + "', telefono = '" + profesional.getTelefono() + "', tituloprofesional = '"
				+ profesional.getTituloprofesional() + "', proyecto = '" + profesional.getProyecto() + "' WHERE runpro = '"
				+ profesional.getRunpro() + "'";

		try {
			con = Singleton.getConnection();
			stm = con.createStatement();
			stm.execute(sql);
			resultado = true;
			stm.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		return resultado;
	}

}
