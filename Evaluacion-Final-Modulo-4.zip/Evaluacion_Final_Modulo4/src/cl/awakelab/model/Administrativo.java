package cl.awakelab.model;

public class Administrativo {

	private String runadm;
	private String nombres;
	private String apellidos;
	private String email;
	private String area;
	private String usuario_runusuario;

	public Administrativo() {
		super();
	}

	public Administrativo(String runadm, String nombres, String apellidos, String email, String area, String usuario_runusuario) {
		super();
		this.runadm = runadm;
		this.nombres = nombres;
		this.apellidos = apellidos;
		this.email = email;
		this.area = area;
		this.usuario_runusuario = usuario_runusuario;
	}

	public String getRunadm() {
		return runadm;
	}

	public void setRunadm(String runadm) {
		this.runadm = runadm;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getUsuario_runusuario() {
		return usuario_runusuario;
	}

	public void setUsuario_runusuario(String usuario_runusuario) {
		this.usuario_runusuario = usuario_runusuario;
	}

	@Override
	public String toString() {
		return "Administrativo [runadm=" + runadm + ", nombres=" + nombres + ", apellidos=" + apellidos + ", email="
				+ email + ", area=" + area + ", usuario_run=" + usuario_runusuario + "]";
	}

}
