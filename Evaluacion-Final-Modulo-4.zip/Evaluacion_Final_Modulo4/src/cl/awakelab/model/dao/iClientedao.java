package cl.awakelab.model.dao;

import cl.awakelab.model.Cliente;

public interface iClientedao {
	
	public Cliente obtenerUsuarioPorId(String runusuario);
	
	public boolean editarCliente(Cliente cliente);
}
