package cl.awakelab.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cl.awakelab.model.dao.ProfesionalDAOImpl;
import cl.awakelab.model.Profesional;

/**
 * Servlet implementation class ActualizarProfesional
 */
@WebServlet("/ActualizarProfesional")
public class ActualizarProfesional extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActualizarProfesional() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String runpro = request.getParameter("runpro");
		String nombres = request.getParameter("nombres");
		String apellidos = request.getParameter("apellidos");
		String telefono = request.getParameter("telefono");
		String tituloprofesional = request.getParameter("tituloprofesional");
		String proyecto = request.getParameter("proyecto");
		String runusuario = "";
		
		Profesional pro = new Profesional(runpro, nombres, apellidos, telefono, tituloprofesional, proyecto, runusuario);
		
		ProfesionalDAOImpl proimpl = new ProfesionalDAOImpl();
		
		boolean res = proimpl.editarProfesional(pro);
		String msg = "";
		
		if (res) {
			msg = "El usuario profesional se edit� exitosamente";
		}
		else {
			msg = "El usuario profesional no se pudo editar porque ocurri� un error";
		}

		request.setAttribute("mensaje", msg);
		request.getRequestDispatcher("/msgcrearprofesional.jsp").forward(request, response);
	}

}
