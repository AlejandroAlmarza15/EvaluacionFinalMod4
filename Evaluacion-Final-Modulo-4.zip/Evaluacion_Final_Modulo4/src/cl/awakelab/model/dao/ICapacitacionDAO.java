package cl.awakelab.model.dao;

import java.util.List;

import cl.awakelab.model.Capacitacion;

public interface ICapacitacionDAO {

	public void createCapacitacion(Capacitacion c);
	public List<Capacitacion> readAll();
	public Capacitacion readOne(int id);
	public void updateCapacitacion(Capacitacion c);
	public void deleteCapacitacion(Capacitacion c);
	public void deleteCapacitacion(int id);
	
	public List<Capacitacion> searchCapacitacion(String busqueda);
}

