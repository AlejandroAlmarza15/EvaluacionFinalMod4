package cl.awakelab.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import cl.awakelab.model.Cliente;

public class ClienteDAOImpl implements iClientedao{

	@Override
	public Cliente obtenerUsuarioPorId(String run_usuario) {
		// TODO Auto-generated method stub
		Connection con = null;
		Statement stm = null;
		ResultSet rs = null;
		Cliente c = new Cliente();
		String sql = "select * from cliente where usuario_runusuario = '"+run_usuario+"'";
		
		try {
			con = Singleton.getConnection();
			stm = con.createStatement();
			rs = stm.executeQuery(sql);
			
			while (rs.next()) {
				c.setRutcliente(rs.getString(1));
				c.setClinombres(rs.getString(2));
				c.setCliapellidos(rs.getString(3));
				c.setClitelefono(rs.getString(4));
				c.setCliafp(rs.getString(5));
				c.setClisistemasalud(rs.getInt(6));
				c.setClidireccion(rs.getString(7));
				c.setClicomuna(rs.getString(8));
				c.setCliedad(rs.getInt(9));
				c.setUsuario_runusuario(rs.getString(10));
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return c;
	
	}

	@Override
	public boolean editarCliente(Cliente cliente) {
		// TODO Auto-generated method stub
		boolean resultado = false;
		Connection con = null;
		Statement stm = null;
		
		String sql = "UPDATE cliente SET clinombres = '" + cliente.getClinombres() + "', cliapellidos = '" 
		+ cliente.getCliapellidos()+ "', clitelefono = '" + cliente.getClitelefono()+ "', cliafp = '" 
		+ cliente.getCliafp()+ "', clisistemasalud = '" 
		+ cliente.getClisistemasalud()+ "', clidireccion = '" + cliente.getClidireccion() 
		+ "', clicomuna = '" + cliente.getClicomuna()+ "', cliedad = '" + cliente.getCliedad()
		+ "' WHERE rutcliente = '" + cliente.getRutcliente() + "'";
		
		try {
			con = Singleton.getConnection();
			stm = con.createStatement();
			stm.execute(sql);
			resultado = true;
			stm.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		return resultado;
	}

}
