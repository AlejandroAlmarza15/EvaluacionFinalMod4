package cl.awakelab.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cl.awakelab.model.dao.AdministrativoDAOImpl;
import cl.awakelab.model.Administrativo;

/**
 * Servlet implementation class ActualizarAdministrativo
 */
@WebServlet("/ActualizarAdministrativo")
public class ActualizarAdministrativo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActualizarAdministrativo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String runadm = request.getParameter("runadm");
		String nombres = request.getParameter("nombres");
		String apellidos = request.getParameter("apellidos");
		String email = request.getParameter("email");
		String area = request.getParameter("area");
		String runusuario = "";
		
		Administrativo adm = new Administrativo(runadm, nombres, apellidos, email, area, runusuario);
		
		AdministrativoDAOImpl admimpl = new AdministrativoDAOImpl();
		
		boolean res = admimpl.editarAdministrativo(adm);
		String msg = "";
		
		if (res) {
			msg = "El usuario administrativo se edit� exitosamente";
		}
		else {
			msg = "El usuario administrativo no se pudo editar porque ocurri� un error";
		}

		request.setAttribute("mensaje", msg);
		request.getRequestDispatcher("/msgcrearadministrativo.jsp").forward(request, response);
		
	}

}
