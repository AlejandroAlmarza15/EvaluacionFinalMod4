package cl.awakelab.model;

public class Usuario {

	private String runusuario;
	private String nombre;
	private String apellido;
	private String fechanacimiento;
	private int tipo;

	public Usuario() {
		super();
	}

	public Usuario(String runusuario, String nombre, String apellido, String fechanacimiento, int tipo) {
		super();
		this.runusuario = runusuario;
		this.nombre = nombre;
		this.apellido = apellido;
		this.fechanacimiento = fechanacimiento;
		this.tipo = tipo;
	}

	public String getRunusuario() {
		return runusuario;
	}

	public void setRunusuario(String runusuario) {
		this.runusuario = runusuario;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getFechanacimiento() {
		return fechanacimiento;
	}

	public void setFechanacimiento(String fechanacimiento) {
		this.fechanacimiento = fechanacimiento;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		return "Usuario [runusuario=" + runusuario + ", nombre=" + nombre + ", apellido=" + apellido
				+ ", fechanacimiento=" + fechanacimiento + ", tipo=" + tipo + "]";
	}

}
