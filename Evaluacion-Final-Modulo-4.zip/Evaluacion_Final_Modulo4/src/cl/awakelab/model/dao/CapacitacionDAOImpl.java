package cl.awakelab.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;

import java.util.List;


import cl.awakelab.model.Capacitacion;

public class CapacitacionDAOImpl implements ICapacitacionDAO {

	@Override
	public void createCapacitacion(Capacitacion cap) {
		// TODO Auto-generated method stub
		try {
		
			String sql = "insert into capacitacion (idcapacitacion, capfecha, caphora, caplugar, capduracion, cliente_rutcliente) values ("
					+ cap.getIdcapacitacion() + ", '" + cap.getCapfecha() + "', '" + cap.getCaphora() + "', '" + cap.getCaplugar()
					+ "', " + cap.getCapduracion()+ ", " + cap.getCliente_rutcliente()+ ")";

			Connection c = Singleton.getConnection();
			Statement s = c.createStatement();

			s.execute(sql);

		} catch (SQLException e) {
			System.out.println("ERROR: m�todo createCapacitacion");
			e.printStackTrace();
		}

	}

	@Override
	public List<Capacitacion> readAll() {
		// TODO Auto-generated method stub
		List<Capacitacion> lista = new ArrayList<Capacitacion>();

		try {
			Connection c = Singleton.getConnection();
			Statement s = c.createStatement();
			String sql = "select idcapacitacion, capfecha, caphora, caplugar, capduracion, cliente_rutcliente from capacitacion";
			//String sql = "select * from capacitacion";
			             
			
			ResultSet rs = s.executeQuery(sql);

			while (rs.next()) {
				lista.add(new Capacitacion(rs.getInt("idcapacitacion"), rs.getString("capfecha"), rs.getString("caphora"), rs.getString("caplugar"), rs.getInt("capduracion"), rs.getString("cliente_rutcliente")));
			}
			
		} catch (SQLException e) {
			System.out.println("ERROR: m�todo readAll()");
			e.printStackTrace();
			
		}
		return lista;
	}

	@Override
	public Capacitacion readOne(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateCapacitacion(Capacitacion c) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteCapacitacion(Capacitacion c) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteCapacitacion(int id) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Capacitacion> searchCapacitacion(String busqueda) {
		// TODO Auto-generated method stub
		return null;
	}

}
